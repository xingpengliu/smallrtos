# include <config.h >
#define timer_delay_const (-22132000/1000)
bdata uint8 keydata;
sbit  keybit0 = keydata^7;
sbit  LED = P1^6;                         // green LED: '1' = ON; '0' = OFF
sbit  key = P3^7;  

void PORT_Init(void);

void main(void)
{  
    WDTCN = 0xde;	//"�ر�WATCHDOG"
   	WDTCN = 0xad;
	OSCXCN= 0x67;
	CKCON = 0x10;
	TMOD  = ((TMOD&0x0f)|0x10);
	TH1=(timer_delay_const>>8);
	TL1=timer_delay_const;
	TR1=1;
//	while(!TF1);
	TR1=0;
	TF1=0;
//	while(!(OSCXCN&0x80));
	OSCICN=0x08;
    PORT_Init();
    EMI0CF  = 0x33;
	TH0=-(9216/256);           //'��ʱ10ms'
  	TL0=-(9216%256);
	TMOD=0X01;
    ET0=1;
	TR0=1;
    OSStart();
   
}

void PORT_Init (void)
{
   XBR2    = 0x40;                     // Enable crossbar and weak pull-ups
   P1MDOUT |= 0x40;                    // enable P1.6 (LED) as push-pull output
}

void LED1(void)

{ 
 
 
     while(1)
    {  
       
       LED=1;
      // OSWait(K_TMO,2);    
      
      //LED=0;
       OSWait(K_TMO,2);
      
     
     }

}
void LED2(void)
{ uint8 ss; 
     while(1)
    {  
	
            
       LED=1;
   
     OSWait(K_TMO,2);       
        LED=0;
     //  OSWait(K_TMO,2);
     }

}

      


